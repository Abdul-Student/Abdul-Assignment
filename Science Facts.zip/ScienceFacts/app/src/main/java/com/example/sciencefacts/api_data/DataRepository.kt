package com.example.sciencefacts.api_data

import com.example.sciencefacts.api_data.requests.login.LoginRequest
import com.example.sciencefacts.api_data.responses.login.LoginResponse
import com.example.sciencefacts.api_data.responses.science.ScienceResponse
import retrofit2.Response
import retrofit2.http.Path

interface DataRepository {
    suspend fun loginAPI(requestData: LoginRequest): Response<LoginResponse>
    suspend fun scienceAPI(keypass: String): Response<ScienceResponse>
}