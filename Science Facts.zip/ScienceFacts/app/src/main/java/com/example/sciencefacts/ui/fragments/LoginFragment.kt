package com.example.sciencefacts.ui.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import com.example.sciencefacts.R
import com.example.sciencefacts.api_data.requests.login.LoginRequest
import com.example.sciencefacts.databinding.FragmentLoginBinding
import com.example.sciencefacts.viewmodels.DataViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@AndroidEntryPoint
class LoginFragment : Fragment() {
    // Binding object for accessing views in the layout
    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!

    // ViewModel to hold and manage UI-related data
    private val viewModel: DataViewModel by activityViewModels()

    // Inflate the layout and initialize the ViewModel and click listeners
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        initViewModel()
        setClickListeners()
        return binding.root
    }

    // Set up click listeners for UI elements
    private fun setClickListeners() {
        with(binding) {
            btnLogin.setOnClickListener {
                // Check if username and password fields are not empty
                if (etPassword.text.toString().isNotEmpty() && etUsername.text.toString().isNotEmpty()) {
                    // Show loading progress while processing the login
                    binding.progressLoading.visibility = View.VISIBLE
                    // Create a login request with the provided username and password
                    val requestData = LoginRequest(username = etUsername.text.toString(), password = etPassword.text.toString())
                    // Trigger the login process in the ViewModel
                    viewModel.loginUser(requestData)
                } else {
                    // Show a toast message if username or password is empty
                    Toast.makeText(context, "Input Username & Password!!", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // Initialize the ViewModel and observe the login response
    private fun initViewModel() {
        viewModel.loginResponse.observe(viewLifecycleOwner, Observer { response ->
            // Check if the response is successful
            if (response.isSuccessful) {
                // Hide the loading progress
                binding.progressLoading.visibility = View.GONE
                // Get the keyPass from the response body
                val keyPass = response.body()?.keypass
                // Navigate to the dashboard fragment with the keyPass as an argument
                CoroutineScope(Dispatchers.Main).launch {
                    val bundle = Bundle()
                    bundle.putString("keyPass", keyPass)
                    findNavController().navigate(R.id.action_loginFragment_to_dashboardFragment, bundle)
                }
                // Show a success message
                Toast.makeText(context, "Login Success", Toast.LENGTH_SHORT).show()
            } else {
                // Hide the loading progress if login failed
                binding.progressLoading.visibility = View.GONE
                // Show a toast message indicating failure
                Toast.makeText(context, "Login Failed\nInvalid Username or Password!!", Toast.LENGTH_SHORT).show()
            }
        })
    }

    // Clean up the binding when the view is destroyed
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
