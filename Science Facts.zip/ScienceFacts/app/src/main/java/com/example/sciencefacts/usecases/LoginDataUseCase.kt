package com.example.sciencefacts.usecases

import com.example.sciencefacts.api_data.DataRepository
import com.example.sciencefacts.api_data.requests.login.LoginRequest
import com.example.sciencefacts.api_data.responses.login.LoginResponse
import com.example.sciencefacts.api_data.responses.science.ScienceResponse
import retrofit2.Response
import javax.inject.Inject

class LoginDataUseCase @Inject constructor(
    private val repository: DataRepository
) {
    suspend operator fun invoke(requestData: LoginRequest): Response<LoginResponse> {
        return repository.loginAPI(requestData)
    }
}