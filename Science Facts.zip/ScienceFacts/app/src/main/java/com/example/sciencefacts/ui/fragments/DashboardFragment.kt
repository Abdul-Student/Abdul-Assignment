package com.example.sciencefacts.ui.fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.sciencefacts.R
import com.example.sciencefacts.api_data.responses.science.ScienceEntity
import com.example.sciencefacts.databinding.FragmentDashboardBinding
import com.example.sciencefacts.ui.adapters.OnScienceItemClickListener
import com.example.sciencefacts.ui.adapters.ScienceAdapter
import com.example.sciencefacts.viewmodels.DataViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class DashboardFragment : Fragment(), OnScienceItemClickListener {
    var keyPass = "" // Variable to hold the key pass for authentication
    private var _binding: FragmentDashboardBinding? = null // Binding variable for the fragment layout
    private val binding get() = _binding!! // Non-nullable binding property
    private val viewModel: DataViewModel by activityViewModels() // ViewModel for managing UI-related data

    // Inflate the fragment layout and initialize views
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        setInitViews() // Call method to set up the initial views
        return binding.root // Return the root view of the fragment
    }

    // Method to initialize views and retrieve key pass
    private fun setInitViews() {
        keyPass = arguments?.getString("keyPass")!! // Retrieve key pass from arguments
        initViewModel() // Initialize the ViewModel to observe data
    }

    // Method to set up the ViewModel observation
    private fun initViewModel() {
        viewModel.scienceResponse.observe(viewLifecycleOwner, Observer { response ->
            // Check if the response is successful
            if (response.isSuccessful) {
                val listOfScience = response.body() // Get the list of science entities from the response
                if (listOfScience != null) {
                    setupRecyclerView(listOfScience.entities) // Set up the RecyclerView with the list of entities
                } else {
                    Toast.makeText(context, "Data Not Found", Toast.LENGTH_SHORT).show() // Show a toast if data is not found
                }
            } else {
                Toast.makeText(context, "Data Not Found", Toast.LENGTH_SHORT).show() // Show a toast for unsuccessful response
            }
        })
        viewModel.scienceData(keyPass) // Call the ViewModel method to fetch science data
    }

    // Method to set up the RecyclerView
    private fun setupRecyclerView(scienceList: List<ScienceEntity>) {
        val scienceAdapter = ScienceAdapter(scienceList, this) // Initialize the adapter with the science list and click listener
        binding.rvScience.layoutManager = LinearLayoutManager(requireContext()) // Set the layout manager for the RecyclerView
        binding.rvScience.adapter = scienceAdapter // Set the adapter to the RecyclerView
    }

    // Clean up the binding when the view is destroyed
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null // Prevent memory leaks by clearing the binding reference
    }

    // Handle item click from the RecyclerView
    override fun onItemClick(scienceEntity: ScienceEntity) {
        // Create a bundle to pass data to the DetailsFragment
        val bundle = Bundle().apply {
            putString("field", scienceEntity.field)
            putString("concept", scienceEntity.concept)
            putString("scientist", scienceEntity.scientist)
            putInt("yearProposed", scienceEntity.yearProposed)
            putString("branch", scienceEntity.branch)
            putString("description", scienceEntity.description)
        }
        // Navigate to the DetailsFragment with the bundle
        findNavController().navigate(R.id.action_dashboardFragment_to_detailsFragment, bundle)
    }
}
