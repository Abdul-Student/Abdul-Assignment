package com.example.sciencefacts.di

import com.example.sciencefacts.api_data.ApiService
import com.example.sciencefacts.api_data.DataRepository
import com.example.sciencefacts.api_data.requests.login.LoginRequest
import com.example.sciencefacts.api_data.responses.login.LoginResponse
import com.example.sciencefacts.api_data.responses.science.ScienceResponse
import retrofit2.Response
import javax.inject.Inject

class DataRepositoryImpl @Inject constructor(
    private val apiService: ApiService
) : DataRepository {

    override suspend fun loginAPI(requestData: LoginRequest): Response<LoginResponse> {
        return apiService.loginAPI(requestData)
    }

    override suspend fun scienceAPI(keypass: String): Response<ScienceResponse> {
        return apiService.scienceAPI(keypass)

    }
}