package com.example.sciencefacts.api_data.responses.science


data class ScienceResponse(
    val entities: List<ScienceEntity>,
    val entityTotal: Int
)
data class ScienceEntity(
    val field: String,
    val concept: String,
    val scientist: String,
    val yearProposed: Int,
    val branch: String,
    val description: String
)

