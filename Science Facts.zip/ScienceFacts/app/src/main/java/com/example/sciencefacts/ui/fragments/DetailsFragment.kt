package com.example.sciencefacts.ui.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.sciencefacts.R
import com.example.sciencefacts.databinding.FragmentDetailsBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class DetailsFragment : Fragment() {
    // Binding object for accessing views in the layout
    private var _binding: FragmentDetailsBinding? = null
    private val binding get() = _binding!!

    // Inflate the layout and initialize the views
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentDetailsBinding.inflate(inflater, container, false)
        setInitViews() // Call method to initialize views with data
        return binding.root // Return the root view of the fragment
    }

    // Method to initialize views and set data
    private fun setInitViews() {
        // Get arguments passed from the previous fragment
        arguments?.let {
            val field = it.getString("field")
            val concept = it.getString("concept")
            val scientist = it.getString("scientist")
            val yearProposed = it.getInt("yearProposed")
            val branch = it.getString("branch")
            val description = it.getString("description")

            // Set data to TextViews
            with(binding) {
                textField.text = "Field: " + field
                textConcept.text = "Concept: " + concept
                textScientist.text = "Scientist: " + scientist
                textYearProposed.text = "Year Proposed: " + yearProposed.toString()
                textBranch.text = "Branch: " + branch
                textDescription.text = "Description: " + description
            }
        }
    }

    // Clean up the binding when the view is destroyed
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null // Prevent memory leaks by clearing the binding reference
    }
}
