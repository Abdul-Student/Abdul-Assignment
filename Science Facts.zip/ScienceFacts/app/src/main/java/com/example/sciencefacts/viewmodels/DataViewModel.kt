package com.example.sciencefacts.viewmodels

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.sciencefacts.api_data.requests.login.LoginRequest
import com.example.sciencefacts.api_data.responses.login.LoginResponse
import com.example.sciencefacts.api_data.responses.science.ScienceResponse
import com.example.sciencefacts.usecases.LoginDataUseCase
import com.example.sciencefacts.usecases.ScienceDataUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

@HiltViewModel
class DataViewModel @Inject constructor(
    private val loginUseCase: LoginDataUseCase,
    private val scienceDataUseCase: ScienceDataUseCase
) : ViewModel() {

    private val _loginResponse = MutableLiveData<Response<LoginResponse>>()
    val loginResponse: LiveData<Response<LoginResponse>> get() = _loginResponse

    private val _scienceResponse = MutableLiveData<Response<ScienceResponse>>()
    val scienceResponse: LiveData<Response<ScienceResponse>> get() = _scienceResponse

    fun loginUser(requestData: LoginRequest) {
        viewModelScope.launch {
            try {
                val result = loginUseCase(requestData)
                _loginResponse.postValue(result)
            } catch (e: Exception) {
                // Handle error
            }
        }
    }
    fun scienceData(keypass: String) {
        viewModelScope.launch {
            try {
                val result = scienceDataUseCase(keypass)
                Log.d("ResulN",result.toString())
                _scienceResponse.postValue(result)
            } catch (e: Exception) {
                // Handle error
            }
        }
    }
}