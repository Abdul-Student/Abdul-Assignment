package com.example.sciencefacts.api_data

object APIConst{
    const val BASE_URL = "https://vu-nit3213-api.onrender.com"
    const val LOGIN_ENDPOINT = "/footscray/auth"
    const val DASHBOARD_ENDPOINT = "/dashboard/"
}