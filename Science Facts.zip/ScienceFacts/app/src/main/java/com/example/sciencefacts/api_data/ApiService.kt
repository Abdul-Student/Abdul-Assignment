package com.example.sciencefacts.api_data

import com.example.sciencefacts.api_data.requests.login.LoginRequest
import com.example.sciencefacts.api_data.responses.login.LoginResponse
import com.example.sciencefacts.api_data.responses.science.ScienceResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface ApiService {
    @POST(APIConst.LOGIN_ENDPOINT)
    suspend fun loginAPI(@Body requestData: LoginRequest): Response<LoginResponse>

    @GET(APIConst.DASHBOARD_ENDPOINT+"{keypass}")
    suspend fun scienceAPI(@Path("keypass") keypass: String): Response<ScienceResponse>
}