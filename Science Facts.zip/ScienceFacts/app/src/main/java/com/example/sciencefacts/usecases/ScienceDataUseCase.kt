package com.example.sciencefacts.usecases

import com.example.sciencefacts.api_data.DataRepository
import com.example.sciencefacts.api_data.requests.login.LoginRequest
import com.example.sciencefacts.api_data.responses.login.LoginResponse
import com.example.sciencefacts.api_data.responses.science.ScienceResponse
import retrofit2.Response
import javax.inject.Inject

class ScienceDataUseCase @Inject constructor(
    private val repository: DataRepository
) {
    suspend operator fun invoke(keypass: String): Response<ScienceResponse> {
        return repository.scienceAPI(keypass)
    }
}