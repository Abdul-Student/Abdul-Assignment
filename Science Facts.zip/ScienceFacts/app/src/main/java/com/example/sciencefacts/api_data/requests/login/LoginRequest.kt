package com.example.sciencefacts.api_data.requests.login

data class LoginRequest(val username: String = "", val password: String = "")