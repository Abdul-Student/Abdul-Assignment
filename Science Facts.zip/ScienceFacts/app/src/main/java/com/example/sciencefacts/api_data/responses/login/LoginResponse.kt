package com.example.sciencefacts.api_data.responses.login

data class LoginResponse(val keypass: String = "")