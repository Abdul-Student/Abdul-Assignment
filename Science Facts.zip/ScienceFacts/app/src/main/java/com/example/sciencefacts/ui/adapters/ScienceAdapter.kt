package com.example.sciencefacts.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.sciencefacts.R
import com.example.sciencefacts.api_data.responses.science.ScienceEntity

class ScienceAdapter(
    private val scienceList: List<ScienceEntity>,
    private val listener: OnScienceItemClickListener
) : RecyclerView.Adapter<ScienceAdapter.ScienceViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ScienceViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.science_view, parent, false)
        return ScienceViewHolder(view)
    }

    override fun onBindViewHolder(holder: ScienceViewHolder, position: Int) {
        val scienceEntity = scienceList[position]
        holder.bind(scienceEntity, listener)
    }

    override fun getItemCount(): Int {
        return scienceList.size
    }

    inner class ScienceViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val fieldTextView: TextView = itemView.findViewById(R.id.text_field)
        private val conceptTextView: TextView = itemView.findViewById(R.id.text_concept)

        fun bind(scienceEntity: ScienceEntity, listener: OnScienceItemClickListener) {
            fieldTextView.text = "Field: "+scienceEntity.field
            conceptTextView.text = "Concept: "+scienceEntity.concept

            itemView.setOnClickListener {
                listener.onItemClick(scienceEntity)
            }
        }
    }
}
interface OnScienceItemClickListener {
    fun onItemClick(scienceEntity: ScienceEntity)
}
